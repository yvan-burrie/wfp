<?php 
	
	// Ever feel you are in wrong place???
	
?>